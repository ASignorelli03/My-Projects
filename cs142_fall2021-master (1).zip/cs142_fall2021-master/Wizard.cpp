#include <iostream>

int main()
{
	int first (0);
	int second (0);
	double third (0);
	std::cout << "\n" "\n" "\n" "\n";
	std::cout << "Welcome to Wizard!" << "\n" "\n";
	
	std::cout << "****Rectangle Area****" << "\n";
	std::cout << "Please enter the length:";
	std::cin >> first;
	std::cout << "Please enter the Width:";
	std::cin >> second;
	third = first * second;
	std::cout << "The area of the Rectangle is:" << third << "\n";
	std::cout << "\n";
	
	std::cout << "****Square Area****" << "\n";
	std::cout << "Please enter the Side length:";
	std::cin >> first;
	third = first * first;
	std::cout << "The area of the Square is:" << third << "\n";
	std::cout << "\n";
	
	std::cout << "****Rhombus Area****" << "\n";
	std::cout << "Please enter the Diagonal 1:";
	std::cin >> first;
	std::cout << "Please enter the Diagonal 2:";
	std::cin >> second;
	third = first * second / 2.0;
	std::cout << "The area of the Rhombus is:" << third << "\n";
	std::cout << "\n";
	
	std::cout << "**** Triangle Area****" << "\n";
	std::cout << "Please enter the Base:";
	std::cin >> first;
	std::cout << "Please enter the Height:";
	std::cin >> second;
	third = first * second / 2.0;
	std::cout << "The area of the Triangle is:" << third << "\n";
	std::cout << "\n";
	
	std::cout << "Thank you! Goodbye!" << "\n" "\n";
	
	return 0;
}