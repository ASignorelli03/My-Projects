#include <iostream>

int main()
{
	std::cout << "Hello CS142" << std::end1;
	
	return 0;
}