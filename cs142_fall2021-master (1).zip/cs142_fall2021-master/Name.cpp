#include <iostream>
#include <string>
int main()
{
	std::string firstname("");
	
	std::string lastname("");
	
	std::cout << "Please enter your first name:  ";
	std::cin >> firstname;
	
	std::cout << "Please enter your last name:  ";
	std::cin >> lastname;
	
	std::cout << "Hello" << " " << firstname << " " << lastname << "!" "\n";
	
	

}



