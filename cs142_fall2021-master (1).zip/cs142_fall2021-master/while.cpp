#include <iostream>

int main()
{
	int x(10000);

	/*while(x>0)
	{
		if(x %2!=0)
		{			
		std::cout<<x<<"\n";
		}
		x--;
	}*/
	
	do
	{
		
		if(x %2==0)
		{			
			x--;
		}
		else
		{
			std::cout<<x<<"\n";
			x--;
		}
		
		
	}while(x>0);
	
	return(0);
}