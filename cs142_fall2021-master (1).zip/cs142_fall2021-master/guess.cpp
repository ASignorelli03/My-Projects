#include <iostream>
#include <string>
// Honor Pledge:
//
// I pledge that I have neither given nor 
// received any help on this assignment.
//
// Anthony Signorelli

int main()
{
	int x(0);//player input
	int guesses(0);//0-7
	char cont(' ');//Yy||Nn
	int type(0);//1||2
	srand((unsigned) time(0));
	
	std::cout<<"Welcome to the CS 142 Guess-o-Matic!"<<"\n";
	do
	{
		char go(' ');//1-2 selection loop
		do
		{
			std::cout<<"1. Human vs. CPU"<<"\n"<<"2. CPU vs. Human"<<"\n""\n"<<"Selection: ";
			std::cin>>type;
	
			if(type > 2 || type <1)//invalid gametype
			{
				std::cout<<"Invalid Selection!"<<"\n";
				go='a';
			}
			else
			{
				go='b';
			}
		}while(go=='a');
		while(type==1)//human guesses
		{	
			x=0;
			//random num assignment
			int randNum(0);
			randNum = (rand() % 100) + 1;
		
			std::cout<<"Ok...I have a random number between 1 and 100..."<<"\n";
			guesses=1;
			while(guesses>=0)
			{
				std::cout<<"Please enter your guess: ";
				std::cin>>x;
				if(x > randNum)
				{
					std::cout<<"You are too high!"<<"\n";
					guesses++;
				
				}
				else if(x < randNum)
				{
					std::cout<<"You are too low!"<<"\n";
					guesses++;
				}
				else
				{
					std::cout<<"CORRECT!!!"<<"\n"<<"It took you "<<guesses<<" total guesses!"<<"\n";
					guesses = -1;//gets out of while
				}
			}
			type=0;
		}
		while(type==2)//cpu guesses
		{
			int max(100);
			int min(0);
			char answer(' ');
			guesses=1;
			char stay('a');

			std::cout<<"Please pick a random number between 1 and 100 for the CPU to guess."<<"\n";
			
			while(stay=='a')//until answer is correct
			{
				int cpuNum=(max+min)/2;
				std::cout<<"\t"<<"CPU Guess: "<<cpuNum;
				std::cout<<"\n"<<"Please respond -(H)igh, (L)ow, or (C)orrect: ";
				std::cin>>answer;
				if(answer=='H'|| answer=='h')//brings min up to the previous guess
				{
					min=cpuNum;
					guesses++;
				}
				else if(answer=='L'|| answer=='l')//brings max down to previous guess
				{
					max=cpuNum;
					guesses++;
				}
				else if(answer=='C'|| answer=='c')
				{
					stay = 'b';
					
				}
				else if(answer!='C'|| answer!='c')
				{
					std::cout<<"Invalid Selection!"<<"\n";//letters not HLC
				}
			}
			std::cout<<"\t"<<"The CPU guessed your number!"<<"\n""\n"<<"It took the CPU "<<guesses<<" total guesses!"<<"\n";
			type=0;
		}
			
		char stay(' ');
		do//y-n selection loop
		{
			std::cout<<"Play again? (Y)es or (N)o: ";
			std::cin>>cont;
			std::cout<<"\n";
			stay=='a';
			if(cont=='y' || cont=='Y')
			{
				stay='b';
			}
			else if (cont=='n' || cont=='N')
			{
				stay='b';
			}
			else
			{
				std::cout<<"Invalid Selection"<<"\n";
				stay='a';
			}
			
			
		}while(stay=='a');
		
		
		
	}while(cont == 'Y' || cont == 'y');

	std::cout<<"\n"<<"Thank you for playing CS 142 Guess-o-Matic -Goodbye!"<<"\n";
	return(0);
}