#include <iostream>
#include <string>
#include <cstring>
#include <sstream>
// Honor Pledge:
//
// I pledge that I have neither given nor 
// received any help on this assignment.
//
// Anthony Signorelli
void reversedWord(char input[], int size);

int main()
{
	char word[100];//string input
	char answer('N');
	
    do 
    {
		std::cout<<"Please enter a word (100 Characters or Less): ";
		
		std::cin>>word;
		
		std::cout<<"Your word spelled backwards is: ";
		
		reversedWord(word,strlen(word));
		
		std::cout<<word;
		
		std::cout<<"\n"<<"Would you like to continue (Y|N)? ";
		
		std::cin>>answer;

		char stay('A');//starts the loop sequence
		while(stay=='A')
		{
			if(answer=='Y')
			{
				stay='B';
			}
			else if(answer=='N')
			{
				stay='B';
			}
			else if(answer != 'Y' || answer != 'N')
			{
				std::cout<<"Invalid Input - Please enter 'Y' or 'N': ";
				std::cin>> answer;
				stay='A';
			}
		}
		char answer('N');
		
    } while (answer != 'N');
	
    std::cout<<"Thank you! Goodbye!"<<"\n";

}

void reversedWord(char input[], int size)
{
	int num(strlen(input)-size);
	char temp(' ');
	
	if(size<=.5*strlen(input))//base case
	{
		return;
	}
	else
	{
		temp = input[num];//swaps 2 outer-most numbers
		input[num] = input[size-1];
		input[size-1] = temp;
		
		reversedWord(input,--size);
	}

}