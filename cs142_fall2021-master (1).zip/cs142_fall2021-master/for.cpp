#include <iostream>

int main()
{
	for(int count(420);count>=0;count--)
	{
		if(count%2==0)
			{
			std::cout<<count<<std::endl;
			}
		else
			{
			}
	}
	return 0;
}