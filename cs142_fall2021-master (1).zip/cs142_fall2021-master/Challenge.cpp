#include <iostream>
#include <string>
// maybe big bang theory???
int main()
{
	int InNum=0;
	int SubNum=0;
	std::string Name("");
	
	
	std::cout<< " What is your name? " << "\n";
	std::cin>> Name;
	std::cout<< "what is your favorite number? " << "\n";
	std::cin>> InNum;
	
	if(InNum!=42)
	{
		std::cout<< "Nope ";
		if(InNum>42)
		{
			SubNum=InNum-42;
			std::cout<<Name<< " Your Guess is " << SubNum<<" away."<<"\n";
		}
		else
		{	
			SubNum=42-InNum;
			std::cout<<Name<<" Your guess is "<< SubNum<<" away."<<"\n";
		}
	}
	else
	{	
		std::cout<<Name<< " Your Correct!!"<<"\n";
	}
	
	
	return(0);
}